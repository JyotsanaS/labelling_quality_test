DIR = "image_data"
